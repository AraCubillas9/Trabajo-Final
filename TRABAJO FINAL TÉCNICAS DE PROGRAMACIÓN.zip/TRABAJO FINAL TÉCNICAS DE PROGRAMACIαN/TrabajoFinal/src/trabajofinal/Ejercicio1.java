/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package trabajofinal;

import java.util.Scanner;

/**
 *
 * @author Araceli Cubillas
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        resolucionEjercicio1();
        
 
        
    }
    public static void resolucionEjercicio1() {
        Scanner teclado = new Scanner(System.in);
        String preguntaConfirmacion = "";
        String preguntaCondicion = "";
        int[] notasCargadas = notasAIngresar();

        do {
            System.out.println("Está seguro/a de las notas que desea cargar? Ingrese 'Sí' o 'No'.");
            preguntaConfirmacion = teclado.nextLine().toLowerCase();

            if (preguntaConfirmacion.equals("no")) {
                notasCargadas = notasAIngresar(); // Actualiza las notas cargadas
            } else if (preguntaConfirmacion.equals("si")) {
                System.out.println("Las notas ingresadas son las siguientes:");
                for (int n : notasCargadas) System.out.println(n);
            } else {
                System.out.println("Respuesta no válida. Ingrese 'Si' o 'No'.");
            }
        } while (!preguntaConfirmacion.equals("si"));

        System.out.println("El promedio de las notas ingresadas es de: " + promedioNotas(notasCargadas));

        do {
            System.out.println("¿Desea conocer la situación del alumno/a? Ingrese 'Si' o 'No'");
            preguntaCondicion = teclado.nextLine().toLowerCase();
            if (preguntaCondicion.equals("si")) {
                System.out.println("La condición del alumno/a es: " + evaluarCondicionDelAlumno(notasCargadas)); break;
            } else if (!preguntaCondicion.equals("no")) {
                System.out.println("Respuesta no válida. Ingrese 'Si' o 'No'.");
            }
        } while (!preguntaCondicion.equals("no"));
    }

    public static int[] notasAIngresar() {
        Scanner notasAIngresar = new Scanner(System.in);
        System.out.println("¿Cuántas notas quiere cargar en el sistema?");
        int cantidadNotasIngresadas = notasAIngresar.nextInt();
        int[] arreglo = new int[cantidadNotasIngresadas];
        System.out.println("Por favor ingrese las " + cantidadNotasIngresadas + " notas que desea cargar:");
        for (int i = 0; i < arreglo.length; i++) {
            System.out.print("Ingrese la nota N° " + (i + 1) + " - ");
            arreglo[i] = notasAIngresar.nextInt();
        }
        return arreglo;
    }

    public static int sumarNotas(int[] notasCargadas) {
        int suma = 0;
        for (int n : notasCargadas) suma += n;
        return suma;
    }

    public static double promedioNotas(int[] notasCargadas) {
        double promedio = (double) sumarNotas(notasCargadas) / notasCargadas.length;
        return promedio;
    }

    public static String evaluarCondicionDelAlumno(int[] notasCargadas) {
    double promedio = promedioNotas(notasCargadas);

    for (int notaAEvaluar : notasCargadas) {
        if (promedio < 6 && notaAEvaluar <= 3) {
            return "NO APROBADO.";
        }
    }

    if (promedio >= 6) {
        return "APROBADO.";
    } else {
        return "EN RECUPERATORIO.";
    }
}
}









    
    
   


